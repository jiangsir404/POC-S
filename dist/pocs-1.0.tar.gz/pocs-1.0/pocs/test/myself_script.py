#!/usr/bin/env python		
#coding:utf-8

"""
测试自定义脚本的加载
"""

def poc(str):
	return True