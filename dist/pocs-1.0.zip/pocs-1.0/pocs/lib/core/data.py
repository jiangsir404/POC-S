#!/usr/bin/env python
# -*- coding: utf-8 -*-
# project = https://github.com/Xyntax/POC-T
# author = i@cdxy.me

from lib.core.log import MY_LOGGER
from lib.core.datatype import AttribDict

logger = MY_LOGGER

paths = AttribDict()

cmdLineOptions = AttribDict()

conf = AttribDict()

th = AttribDict()
