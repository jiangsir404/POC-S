#!/usr/bin/env python
# -*- coding: utf-8 -*-
# project = https://github.com/Xyntax/POC-T
# author = i@cdxy.me

# from lib.utils import versioncheck  # this has to be the first non-standard import
from lib.cli import main

if __name__ == '__main__':
    main()
